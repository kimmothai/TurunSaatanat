document.body.style.backgroundImage = "url('images/turunsaatanatred.png')";

var inserting = browser.tabs.insertCSS(
    file = "/logo.css",
    cssOrigin = "user"
  )